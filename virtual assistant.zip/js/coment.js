'use strict';

// Initialize comments array from localStorage or create an empty array
let commentsArray = JSON.parse(localStorage.getItem('comments')) || [];

// DOM Elements
const userComment = document.querySelector('.usercomment');
const publishBtn = document.querySelector('#publish');
const comments = document.querySelector('.comments');
const userName = document.querySelector('.user');

// Enable or disable publish button based on input
userComment.addEventListener('input', e => {
    if (!userComment.value) {
        publishBtn.setAttribute('disabled', 'disabled');
        publishBtn.classList.remove('abled');
    } else {
        publishBtn.removeAttribute('disabled');
        publishBtn.classList.add('abled');
    }
});

// Function to add a post
function addPost() {
    console.log('The button works');
    if (!userComment.value) return;

    // Create a new comment object
    const newComment = {
        name: userName.value || 'Anonymous',
        identity: userName.value !== 'Anonymous',
        image: userName.value === 'Anonymous' ? '/image/anonymous.png' : '/image/anonymous.png',
        message: userComment.value,
        date: new Date().toLocaleString()
    };

    // Add the new comment to the comments array
    commentsArray.push(newComment);
    // Update localStorage
    localStorage.setItem('comments', JSON.stringify(commentsArray));

    // Clear the input field
    userComment.value = '';
    // Render the comments
    renderComments();
}

// Function to render comments
function renderComments() {
    comments.innerHTML = ''; // Clear existing comments
    commentsArray.forEach(comment => {
        let published = `
            <div class='parents'>
                <img src='${comment.image}' alt='User Image'>
                <div>
                    <h1>${comment.name}</h1>
                    <p>${comment.message}</p>
                    <div class='engagements'>
                        <img src='/image/like.png' alt='Like'>
                        <img src='/image/share.png' alt='Share'>
                    </div>
                    <span class='date'>${comment.date}</span>
                </div>   
            </div>`;
        comments.innerHTML += published; // Append each comment
    });
    // Update comment count
    document.getElementById('comment').textContent = commentsArray.length;
}

// Event listener for the publish button
publishBtn.addEventListener('click', addPost);

// Render comments on page load
document.addEventListener('DOMContentLoaded', renderComments);